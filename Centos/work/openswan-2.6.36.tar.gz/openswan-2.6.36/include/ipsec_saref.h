#ifndef IP_IPSEC_REFINFO
#define IP_IPSEC_REFINFO 22
#endif

#ifndef IP_IPSEC_BINDREF
#define IP_IPSEC_BINDREF 23
#endif

